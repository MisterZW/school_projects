Name: Zachary Whitney
ID #: 3320178
PittID: zdw9
CS 447  MWF 11AM  Recitation: W 4PM
Project 2 -- Single-cycle CPU
Version 2 (w/ extra credit)

All ISA operations and test programs should work as specified.
I completed all 4 extra credit operations as well.

The product register and logic is on the right of the main circuit. There's a little bit of interconnect logic for the RAM on the main circuit also. All of the extra credit components and logic are toward the bottom of the main circuit. It was easier to separate their implementation from the rest of the control that way.

Otherwise, the rest is in labeled components which should be pretty easy to work out. There's some violation of input/output directional conventions in favor of getting the components to take up less space on the main circuit. 

Thanks!




