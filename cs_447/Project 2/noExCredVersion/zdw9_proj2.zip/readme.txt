Name: Zachary Whitney
ID #: 3320178
PittID: zdw9
CS 447  MWF 11AM  Recitation: W 4PM
Project 2 -- Single-cycle CPU

All ISA operations and test programs should work as specified.
I did not complete any extra credit.

The product register and logic is on the right of the main circuit. There's a little bit of interconnect logic for the RAM on the main circuit also. 

Otherwise, the rest is in labeled components which should be pretty easy to work out. There's some violation of input/output directional conventions in favor of getting the components to take up less space on the main circuit, but I don't think it's that hard to figure out what's going on. 


